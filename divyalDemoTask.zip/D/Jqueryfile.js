//  <!-- VALIDATIONS IN THE EMPLOYEE FROM SCRIPT OF THE ADD EMPLOYEE  -->

$(document).ready(function () {
    $("#addEmp_btn").click(function () {
        setTimeout(() => {
            console.log("Add employee validation")
        }, 2000);console.log('hello buddy');
        $('#employeeform').validate({
            rules: {
                eName: {
                    required: true,
                    minlength: 3
                },
                email: {
                    required: true,
                    // minlength: 2
                },
                mob: {
                    required: true,
                    minlength: 10
                },
                add: {
                    required: true,
                    minlength: 5
                },
                dob: {
                    required: true,
                    // minlength: 2
                },

                doj: {
                    required: true,
                    // minlength: 3
                },
                gender: {
                    required: true,
                    // minlength: 3
                },
                active: {
                    required: true,
                    // minlength: 3
                },
                dId: {
                    required: true,
                    // minlength: 3
                }

            },
            messages: {
                eName: {
                    required: "Enter your name",
                    minlength: "name must be atleast 3 characters long"
                },
                email: {
                    required: "Enter your email id",
                    // minlength: "your Branch must be atleast 3 characters long"
                },
                mob: {
                    required: "Enter your mobile number",
                    minlength: "Mobile number must be 10 characters long"
                },
                add: {
                    required: "Enter your address",
                    minlength: "Address must be at least 5 characters long"
                },
                dob: {
                    required: "Choose your date of birth",
                    // minlength: "Your password must be at least 3 characters long"
                },
                doj: {
                    required: "your date of joining",
                    minlength: "Your password must be at least 3 characters long"
                },
                gender: {
                    required: "Select your gender",
                    // minlength: "Your password must be at least 3 characters long"
                },
                active: {
                    required: "Select your status",
                    minlength: "Your password must be at least 3 characters long"
                },
                dId: {
                    required: "Your department",
                    // minlength: "Your password must be at least 3 characters long"
                }
            },
        });
    })
    // console.log("Ready");
    $("#addEmp_btn_form").click(function () {
        console.log("inside the ADD EMPLOYEE button")
        console.log("validate", $('#employeeform').valid())
        console.log($('#eName').val());
        console.log($('#email').val());
        console.log($('#mob').val());
        console.log($('#add').val());
        console.log($('#dob').val());
        console.log($('#doj').val());
        console.log($("input:radio[name=gender]:checked").val());
        console.log($('#active').val());
        console.log($('#dId').val());
        if ($('#employeeform').valid()) {
            $.ajax({
                url: 'addEmp1.php',
                type: 'post',
                data: {
                    k1: $('#eName').val(),
                    k2: $('#email').val(),
                    k3: $('#mob').val(), 
                    k4: $('#add').val(),
                    k5: $('#dob').val(),
                    k6: $('#doj').val(),
                    k7: $("input:radio[name=gender]:checked").val(),
                    k8: $('#active').val(),
                    k9: $('#dId').val(),
                },
                success: function (response) {
                    console.log("response");
                    $('#employeeform').trigger('reset');
                    var table = $('#table1').DataTable();
                    table.ajax.reload();
                    alert("Employee Added Successfully")
                }
            });
        }
    });

    // SCRIPT CODE FOR THE ADD DEPARTMENT start here:
    $("#addDept_btn").click(function () {
        setTimeout(() => {
            console.log("validation of Department")
        }, 2000);
        $("form[id='deptForm']").validate({
            rules: {
                dName: {
                    required: true,
                    minlength: 3
                },

                dType: {
                    required: true,
                    // minlength: 2
                },
                active: {
                    required: true,
                    // minlength: 10
                },
                address: {
                    required: true,
                    // minlength: 5
                }
            },
            messages: {
                dName: {
                    required: "Enter your department name",
                    minlength: "name must be atleast 3 characters long"
                },
                dType: {
                    required: "Choose your department type",
                },
                active: {
                    required: "Choose your active status",
                },
                address: {
                    required: "Enter your address",
                }
            },

        });
    })
    // console.log("Ready Inside add Department");

    $("#addDept_btn_form").click(function () {
        console.log("inside click button");
        // console.log($('#dName').val());
        // console.log($('#dType').val());
        // console.log($('#active').val());
        // console.log($('#address').val());
        if ($('#deptForm').valid()) {
            $.ajax({
                url: 'addDept1.php',
                type: 'post',
                data: {
                    k1: $('#dName').val(),
                    k2: $('#dType').val(),
                    k3: $('#active').val(),
                    k4: $('#address').val(),
                },
                success: function (response) {
                    console.log("responded");
                    $('#deptForm').trigger('reset');
                }
            });
        }
    });

    var any;

    // Define the DataTable with AJAX and column rendering
    $(document).ready(function () {
        var table = $('#table1').DataTable({
            "ajax": "fetchingData.php",
            "columns": [
                { data: 'id' },
                { data: 'emp_name' },
                { data: 'dName' },
                { data: 'mobile' },
                { data: 'email' },
                {
                    data: null,
                    render: function (data, type, row) {
                        return '<button type="button" class="btn btn-primary editButton" id="editUpdateEmp" data-toggle="modal" data-target="#editUpdateEmployee">Edit</button>';
                    }
                },
                {
                    data: null,
                    render: function (data, type, row) {
                        return '<button type="button" class="btn btn-light viewButton" data-toggle="modal" data-target="#viewDetailsModal">View</button>';
                    }
                },
                {
                    data: null,
                    render: function (data, type, row) {
                        return '<button type="button" class="btn btn-danger delButton" data-toggle="modal" data-target="#delDetailsModal">Delete</button>';
                    }
                }
            ]
        });

        // Add event listeners for the buttons
        $('#table1 tbody').on('click', '.editButton', function () {
            var data = table.row($(this).parents('tr')).data();
            editButton(data.id);
        });
        var id
        $('#table1 tbody').on('click', '.viewButton', function () {
            // Handle view button click here     
            var data = table.row($(this).parents('tr')).data();
            viewButton(data.id);
        });

        $('#table1 tbody').on('click', '.delButton', function () {
            var data = table.row($(this).parents('tr')).data();
            delButton(data.id);
        });
    });
  
    function editButton(idValue) {
        any=idValue;
        console.log("Edit the value of id of the row  " + idValue);
           $.ajax({
            url: 'editData.php',
            type: 'post',
            data: {
                id: idValue,
            },
            success: function (data) {
                var json= JSON.parse(data);
                $('#_eName').val(json.emp_name);
                $('#_email').val(json.email);         
                $('#_mob').val(json.mobile);       
                $('#_add').val(json.address);
                $('#_dob').val(json.dob);
                $('#_doj').val(json.doj);
                $('#_gender').val(json.gender);
                $('#_active').val(json.active);
                $('#_dId').val(json.dept_id);
           },
            error: function (xhr, status, error) {
                console.log("Error: " + error);
            }
        });
    }    


    $("#updateEmp_btn").click(function () {
        console.log(any);
        console.log("UPDATE EMPLOYEE BTN.")
        console.log($('#_eName').val());
        console.log($('#_doj').val());;
        console.log($('#_dId').val());
        $.ajax({
            url: 'updateTheDataOfEmp.php',
            type: 'post',
            data: {
                anything: any,
                k1: $('#_eName').val(),
                k2: $('#_email').val(),
                k3: $('#_mob').val(),
                k4: $('#_add').val(),
                k5: $('#_dob').val(),
                k6: $('#_doj').val(),
                k7: $('#_gender').val(),
                k8: $('#_active').val(),
                k9: $('#_dId').val(),
            },
            success: function (response) {
                // console.log(data);
                console.log("response");
                $('#employeeformUpdate').trigger('reset');
                alert("Record Updated Successfully")
                var table = $('#table1').DataTable();
                table.ajax.reload();
            }
        });
        
    });



    function viewButton(idValue) {
        any=idValue;
        console.log("Viewing value of id of the row  " + idValue);
           $.ajax({
            url: 'viewData.php',
            type: 'post',
            data: {
                id: idValue,
            },
            success: function (data) {
                
                var json= JSON.parse(data);
                console.log("----",json.emp_name);
                $('#eName1').val(json.emp_name);
                $('#email1').val(json.email);         
                $('#mob1').val(json.mobile);       
                $('#add1').val(json.address);
                $('#dob1').val(json.dob);
                $('#doj1').val(json.doj);
                $('#gender1').val(json.gender);
                $('#active1').val(json.active);
                $('#dId1').val(json.dept_id);
               // $('#editUpdateEmployee').modal('editUpdateEmployee');
           },
            error: function (xhr, status, error) {
                console.log("Error: " + error);
            }
        });
    }

    function delButton(idValue) {
        console.log('Delete the record of  ' + idValue);
        if (confirm('Are you sure want to delete this user ?')) {
            $.ajax({
                url: 'delData.php',
                type: 'post',
                data: {
                    del: idValue
                },
                success: function (data) {
                     console.log(data);
                    var json = JSON.parse(data);
                    var status = json.status;
                    if (status === 'success') {
                        $('#' + idValue).closest('tr').remove();
                        // console.log("Record of the id." + del + " has been deleted");
                        $('#table1').DataTable().draw();
                        var table = $('#table1').DataTable();
                        table.ajax.reload();
                    }
                    else {
                        alert('Failed');
                    }                    
                },
                error: function (xhr, status, error) {
                    console.log("Error: " + error);
                }
            });
        }
    }


    $("#searchData").click(function () {
        var employeeName = $("#employeeNameS").val();
        var email = $("#emailS").val();
        var mobile = $("#mobileS").val();
        var department = $("#departmentS").val();
        console.log(department);
        // Create an object to send as data for searching
        var searchData = {
            employeeName: employeeName,
            email: email,
            mobile: mobile,
            department: department,
        };
    
        // Get a reference to the DataTable
        var table = $('#table1').DataTable();
    
        // Perform an AJAX call to fetchingdata.php to fetch search results
        $.ajax({
            url: 'fetchingdata.php', // Update the URL to the actual path of your fetchingdata.php file
            type: 'POST',
            data: searchData,
            dataType: 'json', // Expect JSON response
            success: function (data) {
                console.log(data);    
                // Clear the existing table and add new data
                table.clear().rows.add(data.data).draw(); // Update the DataTable with the search results
    
                console.log("Search records");
            },
            error: function (xhr, status, error) {
                console.log("Error: " + error);
            }
        });
    });
        

    
});