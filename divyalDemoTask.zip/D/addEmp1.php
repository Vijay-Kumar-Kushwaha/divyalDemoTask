<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Add|Emp</title>

</head> 
<body>
    <?php                     
        $eName = $_POST["k1"];
        $email = $_POST["k2"];
        $mobile = $_POST["k3"];
        $address = $_POST["k4"];
        $dofb = $_POST["k5"];
        $dofj = $_POST["k6"];
        $gender = $_POST["k7"];
        $active = $_POST["k8"];
        $dId = $_POST["k9"];
        // echo($eName+"<br>");
        // echo($c);
        $con=mysqli_connect('localhost','root','','divyal');
        $q1="insert into emp (emp_name, address, mobile, email, dob, doj, gender, active, dept_id) values('$eName','$address', '$mobile', '$email', '$dofb','$dofj', '$gender', '$active','$dId')";
        $rs=mysqli_query($con, $q1);     
        if($rs)
        {
        echo $rs;
        echo $dofb;
        echo $dofj;
        }
        else
        {
          echo"Error";
        }            
    ?>

<!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script> -->
</body>
</html>