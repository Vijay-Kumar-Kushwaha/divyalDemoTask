<?php
$con = mysqli_connect('localhost', 'root', '', 'divyal') or die('Error ' . mysqli_error($con));

if (isset($_POST['employeeName']) || isset($_POST['email']) || isset($_POST['mobile']) || isset($_POST['department'])) {

    $sql = "SELECT * FROM emp WHERE 1";

 
    if (!empty($_POST['employeeName'])) {
        $employeeName = mysqli_real_escape_string($con, $_POST['employeeName']);
        $sql .= " AND emp_name LIKE '%$employeeName%'";
    }

    if (!empty($_POST['email'])) {
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $sql .= " AND email LIKE '%$email%'";
    }

    if (!empty($_POST['mobile'])) {
        $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
        $sql .= " AND mobile LIKE '%$mobile%'";
    }

    if (!empty($_POST['department'])) {
        $department = mysqli_real_escape_string($con, $_POST['department']);
        $sql .= " AND SELECT * FROM dept WHERE  dept_id = $department";
    }

    $result = mysqli_query($con, $sql);

    $data = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }


    echo json_encode($data);
} else {

    echo json_encode(array());
}

mysqli_close($con);
?>
