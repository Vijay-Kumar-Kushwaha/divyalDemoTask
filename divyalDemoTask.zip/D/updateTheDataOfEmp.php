<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Updating data of Employee</title>

</head>
<body>
    <?php                     
        $a = $_POST["anything"];
        echo $a;
        $_eName = $_POST["k1"];
        $_email = $_POST["k2"];
        $_mobile = $_POST["k3"];
        $_address = $_POST["k4"];
        $_dofb = $_POST["k5"];
        $_dofj = $_POST["k6"];
        $_gender = $_POST["k7"];
        $_active = $_POST["k8"];
        $_dId = $_POST["k9"];
        // echo($eName+"<br>");
        // echo($c);
        $con=mysqli_connect('localhost','root','','divyal');
        $q1= "update emp set emp_name='$_eName', address='$_address', email='$_email', dob='$_dofb', doj='$_dofj', gender='$_gender', active='$_active', dept_id='$_dId', mobile='$_mobile' where id=$a";
        $rs=mysqli_query($con, $q1);     
        if($rs)
        {
        echo $rs;  //is success then it prints '1' in console;
        }
        else
        {
          echo"Error";
        }            
    ?>

<!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script> -->
</body>
</html>