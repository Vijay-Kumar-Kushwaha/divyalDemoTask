<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="Jqueryfile.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
   
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.css">    
    
    <!-- CDNs FRO VALIDATIONS -->
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous"> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>    
   
    <link rel="stylesheet" href="style.css">
    <title>Home|Page</title>

</head>
<body>
    <!-- MAIN FORM -->
    <form>
        <div class="container"   style="background-color:rgb(134, 202, 229)">
        <h2 class="py-3 text-center">Employee Search</h2>
        <div class="row py-3">
        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                <div class="form-group">
                    <label>Employee Name</label>
                    <input type="text" class="form-control" id="employeeNameS" >
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" id="emailS">
                </div>
            </div>
            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                <div class="form-group">
                    <label>Mobile</label>
                    <input type="text" class="form-control" id="mobileS" >
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select name="" id="departmentS" class="form-control">
                    <option value="">...</option>
                    <option value="1">Technical</option>
                    <option value="2">Non Technical</option>
                    <option value="3">Analyst</option>
                    <option value="4">Testing</option>                    
                    </select>
                </div>            
            </div>    
                <div class="col-12 col-lg-4 col-md-4 col-sm-4">
                    <button type="button" class="btn btn-primary eb2 mb-1" id="searchData" style="float:right">Search</button>
                </div>
                <div class="col-12 col-lg-3 col-md-3 col-sm-3">
                    <button type="button" class="btn btn-primary eb2 mb-1"  id="addEmp_btn" data-toggle="modal" data-target="#exampleModal">Add Employee</button>
                </div>
                <div class="col-12 col-lg-5 col-md-5 col-sm-5">
                    <button type="button" class="btn btn-primary eb2 mb-1" id="addDept_btn"data-toggle="modal" data-target="#addEmpModal"style="float:start" >Add Department</button>
            </div>  

            <!-- MODAL OF THE ADD EMPLOYEE FORM-->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">EMPLOYEE FORM</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <!--BODY OF THE MODAL FOR ADD EMPLOYEE -->
                        <div class="modal-body">  
                            <div class="a" >
                                <form id="employeeform">
                                    <div class="container"   style="background-color:rgb(134, 202, 229)">                    
                                        <p> <img src="logo.jpg" alt="Divyal Logo" width="50" height="50"> <label class="ael1 fw-bold text-center">Add Employee</label></p> 
                                        <div class="row py-3">                            
                                            <div class="col-12 col-lg-12 col-md-12 col-sm-12">
                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>Employee Name</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <input type="text" class="form-control" id="eName" name='eName'>                
                                                    </div>
                                                </div>
                                                <!-- </div> -->
                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>Email</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <input type="email" class="form-control" id="email" name='email'>
                                                    </div>    
                                                </div>

                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>Mobile</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <input type="text" class="form-control" id="mob" name='mob' oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>Address</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <input type="text" class="form-control" id="add"name='add'>
                                                    </div>
                                                </div>

                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>DOB</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <input type="date" class="form-control" id="dob" name='dob'>
                                                    </div>
                                                </div>

                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>Doj</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <input type="date" class="form-control" id="doj" name='doj'>
                                                    </div>
                                                </div>
                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label> Gender</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <div class="form-check d-flex" style="float:left">                                                
                                                            <input type="radio" class="form-check-input"  name="gender" value="M">
                                                            <label for="maleradio" class="form-check-label form-inline"  name="gender" value="M" id="gender">Male</label>
                                                            <input type="radio" class="form-check-input" name="gender" value="F" >
                                                            <label for="femaleradio" class="form-check-label form-inline" value="F" name="gender" id="gender" >Female</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>Active</label>
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <select class="form-control" id="active" name='active'>
                                                            <option value="">.....</option>
                                                            <option value="0">Status: No</option>
                                                            <option value="1">Status: Yes</option>
                                                        </select>
                                                    </div>
                                                </div> 
                                                <div class="form-group form-inline">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <label>Department id</label>                            
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <select class="form-control" id="dId" name='dId'>
                                                            <option value="">.....</option>
                                                            <option value="1">Technical</option>
                                                            <option value="2">Non Technical</option>
                                                            <option value="3">Analyst</option>
                                                            <option value="4">Testing</option>
                                                        </select>
                                                    </div>
                                                </div>  
                                                <!-- <div class="col-12 col-lg-12 col-md-12 col-sm-12"> -->
                                                    <div class="row">
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <input type="button"  value="Add/Update" class="btn btn-primary eb1" id="addEmp_btn_form" style="float:right">
                                                    </div>
                                                    <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                        <!-- <div class=" justify-content-center"> -->
                                                           
                                                            <a href="index.php"class="ms-2"><input type="button" value="Back" class="btn btn-primary" id="zz"></a>
                                                        <!-- </div> -->
                                                    </div>
                                                    </div>
                                                <!-- </div> -->
                                            </div>
                                        </div>  
                                    </div>
                                </form>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>   
                
            <table id="table1" class="display" style="width:80%">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Employee Name</th>
                        <th>Department</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Action</th>
                        <th>Action</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>  
        </div>
    </form>
    <!--MODAL OF THE "ADD DEPARTMENT" -->
    <div class="modal fade" id="addEmpModal" tabindex="-1" aria-labelledby="addEmpModal" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ADD DEPARTMENT FORM</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">                
                    <form id="deptForm">
                        <div class="container"   style="background-color:rgb(134, 202, 229)">                            
                            <p> <img src="logo.jpg" alt="Divyal Logo" width="50" height="50"> <label class="ael1">Add Department</label></p> 
                            <div class="row py-3">
                                <div class=" col-12 col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group form-inline">
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Department Name</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <input type="text" class="form-control" id="dName" name="dName">                
                                        </div>
                                    </div>
                                    <div class="form-group form-inline">
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Department type</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <select class="form-control"  id="dType" name="dType">
                                                <option></option>
                                                <option>IT</option>
                                                <option>Tech</option>
                                                <option>Non_Tech</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group form-inline">
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Active</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <select class="form-control" id="active" name="active">
                                                <option></option>
                                                <option value="0">0 (Not Active)</option>
                                                <option Value="1">1 (Active)</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group form-inline">
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Address/Block</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <select class="form-control" id="address" name="address">
                                                <option></option>
                                                <option>Bhilai</option>
                                                <option>Risali</option>
                                                <option>Durg</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>  
                            <div class="row mb-2">
                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                <input type="button"  value="Add/Update"class="btn btn-primary eb1" id="addDept_btn_form" style="float:right">
                            </div>
                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                <a href="index.php"><input type="button" value="BACK" class="btn btn-primary ms-2" id="zz"></a>
                                </div>
                            </div>         
                        </div>
                    </form>    
                </div>
            </div>
        </div>
    </div>               



    <!-- MODAL OF EDIT/UPDATE DATA IOF THE EMPLOYEE-->
    <div class="modal fade" id="editUpdateEmployee" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-body">
                    <div class='a' >
                        <form id='employeeform'>
                            <div class='container'   style='background-color:rgb(134, 202, 229)'>                                    
                                <p> <img src='logo.jpg' alt='Divyal Logo' width='50' height='50'> <label class='ael1'>Edit Employee Details</label></p> 
                                <div class='row py-3'>
                                    <div class="col-12 col-lg-12 col-md-12 col-sm-12">
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>Employee Name</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <input type='text' class='form-control' id='_eName' name='eName'>                
                                            </div>
                                        </div>
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <input type='email' class='form-control' id='_email'value='$row[email]' name='email'>
                                            </div>
                                        </div>                            
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>Mobile</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <input type='text' class='form-control' id='_mob' name='mob'value='$row[mobile]'oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                            </div>
                                        </div>
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>Address</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <input type='text' class='form-control' id='_add'name='add' value='$row[address]'>
                                            </div>
                                        </div>                            
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>DOB</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <input type='date' class='form-control' id='_dob' value='$row[dob]' name='dob'>
                                            </div>
                                        </div>                            
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>Doj</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <input type='date' class='form-control' id='_doj' name='doj' value='$row[doj]'>
                                            </div>
                                        </div>
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label> Gender</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <div class='form-check' style=" float:left">
                                                    <input type='radio' class='form-check-input'  name='gender' value='M'>
                                                    <label for='maleradio' class='form-check-label form-inline'  name='gender' value='$row[gender]' value='M' id='_gender'>Male</label>
                                                    <input type='radio' class='form-check-input' name='gender' value='F' >
                                                    <label for='femaleradio' class='form-check-label form-inline' value='F' name='gender' value='$row[gender]' id='_gender' >Female</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>Active</label>
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <select class='form-control' id='_active' name='active' value='$row[active]'>
                                                    <option value=''>.....</option>
                                                    <option value='0'>Status: No</option>
                                                    <option value='1'>Status: Yes</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class='form-group form-inline'>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <label>Department id</label>                            
                                            </div>
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <select class='form-control' id='_dId' name='dId' value='$row[dept_id]'>
                                                    <option value=''>.....</option>
                                                    <option value='1'>Technical</option>
                                                    <option value='2'>Non Technical</option>
                                                    <option value='3'>Analyst</option>
                                                    <option value='4'>Testing</option>
                                                </select>
                                            </div>
                                        </div>        
                                        <div class="row">
                                            <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                                <input type='button'  value='Edit Employee Details'class='btn btn-primary eb1' id='updateEmp_btn' style="float:right">
                                            </div>
                                            <div class="col-12 col-lg-1 col-md-1 col-sm-1">
                                                <a href='index.php'><input type='button' value='Back' class='btn btn-primary' id='zz' style="float:left"></a>
                                            </div>
                                            <div class="col-12 col-lg-5 col-md-5 col-sm-5"></div>
                                        </div>                
                                    </div>
                                </div>          
                            </div>
                        </form>
                    </div>                                                            
                </div>
            </div>
        </div>
    </div>         

    <!-- MODAL FOR VIEWING THE EMPLOYEE DETAILS -->
    <div class="modal fade" id="viewDetailsModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-body">
                    <form id='employeeformUpdate'>
                        <div class='container'   style='background-color:rgb(134, 202, 229)'>                                
                            <p> <img src='logo.jpg' alt='Divyal Logo' width='50' height='50'> <label class='ael1'>Viewing Details of Employee</label></p> 
                            <div class='row py-3'>                                
                                <div class="col-12 col-lg-12 col-md-12 col-sm-12">
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Employee Name</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <input type='text' class='form-control' id='eName1' name='eName'>                
                                        </div>
                                    </div>
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Email</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <input type='email' class='form-control' id='email1'value='$row[email]' name='email'>
                                        </div>
                                    </div>
                    
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Mobile</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <input type='text' class='form-control' id='mob1' name='mob'value='$row[mobile]' oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                        </div>
                                    </div>
                                    
                    
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Address</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <input type='text' class='form-control' id='add1'name='add' value='$row[address]'>
                                        </div>
                                    </div>
                    
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>DOB</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <input type='date' class='form-control' id='dob1' value='$row[dob]' name='dob'>
                                        </div>
                                    </div>
                    
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Doj</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <input type='date' class='form-control' id='doj1' name='doj' value='$row[doj]'>
                                        </div>
                                    </div>
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label> Gender</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <div class='form-check' style="float:left">
                                                <input type='radio' class='form-check-input'  name='_gender' value='M'>
                                                <label for='maleradio' class='form-check-label form-inline'  name='gender' value='$row[gender]' value='M' id='gender1'>Male</label>
                                                <input type='radio' class='form-check-input' name='_gender' value='F' >
                                                <label for='femaleradio' class='form-check-label form-inline' value='F' name='gender' value='$row[gender]' id='gender1' >Female</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Active</label>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <select class='form-control' id='active1' name='active' value='$row[active]'>
                                                <option value=''>.....</option>
                                                <option value='0'>Status: No</option>
                                                <option value='1'>Status: Yes</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class='form-group form-inline'>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <label>Department id</label>                            
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-6">
                                            <select class='form-control' id='dId1' name='dId' value='$row[dept_id]'>
                                                <option value=''>.....</option>
                                                <option value='1'>Technical</option>
                                                <option value='2'>Non Technical</option>
                                                <option value='3'>Analyst</option>
                                                <option value='4'>Testing</option>
                                            </select>
                                        </div>
                                    </div>         
                                    <div class="row mt-3">
                                        <div class="col-12 col-lg-4 col-md-4 col-lg-4"></div>
                                        <div class="col-12 col-lg-2 col-md-2 col-lg-2">
                                            <a href='index.php'><input type='button' value='HOME' class='btn btn-primary' id=' zz'></a>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-lg-6"></div>
                                    </div>
                                </div>
                            </div>          
                        </div>
                    </form>        
                </div>
            </div>
        </div>
    </div> 



    <script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js" charset="utf8" type="text/javascript"></script>    
</body>
</html> 