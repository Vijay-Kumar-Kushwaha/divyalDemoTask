
    <?php        
    $d = $_POST['del'];
    $con = mysqli_connect('localhost','root','','divyal') or die('Error ' . mysqli_error($con));
    $sql = "DELETE  FROM emp WHERE id = '$d'";
    $query = mysqli_query($con, $sql);
    if($query==true)
    {
        $data = array(
            'status' => 'success',
        );
         echo json_encode($data);
    }
    else 
    {
        $data = array(
            'status' => '_failed_',
        );
        echo json_encode($data);
    }
    ?>