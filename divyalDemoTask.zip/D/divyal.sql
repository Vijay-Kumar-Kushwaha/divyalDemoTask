-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2024 at 10:51 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `divyal`
--

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `id` int(11) NOT NULL,
  `dName` varchar(100) NOT NULL,
  `dType` varchar(100) NOT NULL,
  `active` int(11) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`id`, `dName`, `dType`, `active`, `address`) VALUES
(1, 'Technical', 'Tech', 1, 'Bhilai'),
(2, 'Non Technical', 'Non_Tech', 1, 'Risali'),
(3, 'Analyst', 'Tech', 1, 'Risali'),
(4, 'Testing', 'Tech', 1, 'Bhilai'),
(16, 'Technical', 'Tech', 0, 'Risali');

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE `emp` (
  `id` int(11) NOT NULL,
  `emp_name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `doj` date NOT NULL,
  `gender` varchar(2) NOT NULL,
  `active` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`id`, `emp_name`, `address`, `mobile`, `email`, `dob`, `doj`, `gender`, `active`, `dept_id`) VALUES
(12530, 'Shree MS dhoni', 'Ayodhya', '1111184567', 'shoni123@gmail.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12534, 'ram ji', 'Ayodhya', '1111184567', 'ram@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12535, 'raunit', 'vrindavan', '1234567844', 'rauno@yahoo.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12536, 'yuvraj', 'Ayodhya', '1111184567', 'yuvi@gmail.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12538, 'sanjay', 'Ayodhya', '1111184567', 'sanjay@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12539, 'ajay', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12543, 'shahrukh', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12544, 'Salman', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12545, 'akshay', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12546, 'Asif sir', 'Green Valley', '9999912345', 'asif@outlook.com', '1996-10-06', '2021-10-20', 'M', 1, 1),
(12547, 'hari bol bhai', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12548, 'Vijay', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12549, 'prem', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12550, 'arvind', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12553, 'Akash', 'Ayodhya', '1111184567', 'harry@outlook.com', '2023-10-06', '2023-10-20', 'M', 1, 2),
(12554, 'jethalal', 'gokuldham', '1234523434', 'jethiya@123gmail.com', '2023-10-02', '2023-11-11', 'M', 1, 3),
(12555, 'Iyer', 'gokuldham', '1234567897', 'iyeridli123@rediffmail.com', '1987-12-12', '1989-03-12', 'M', 1, 2),
(12556, 'Babita ji', 'gokuldham bangal', '2341232343', 'babita123@rediffmail.com', '2011-12-12', '1999-12-19', 'F', 1, 2),
(12557, 'tarak mehta', 'gokuldham mumbai', '1234561234', 'tkm1234@yahoo.com', '1998-12-12', '1999-04-14', 'M', 0, 3),
(12558, 'hello world', 'digital media STPI', '1234123456', 'helloowrld@outlook.com', '1945-02-12', '1945-02-13', 'M', 1, 2),
(12560, 'raja baba', 'bihar se hai', '9876232323', 'rajababa@divyaltech.com', '2023-12-22', '2023-12-13', 'M', 1, 2),
(12561, 'Pulkit Sharma', 'pukhrajpur', '7878787899', 'pluck12@gmail.com', '2024-01-31', '2024-01-26', 'M', 1, 1),
(12569, 'Vijay Kumar Kushwhaha', 'Bajrang Chowk, Krishna nagar Supela, BHILAI', '6387426865', 'vijay77495@gmail.com', '2024-01-05', '2024-01-05', 'M', 1, 1),
(12570, 'Hello World in PHP', 'gjgjasd ', '6387426865', 'hw213@gmail.com', '2024-01-05', '2024-01-05', 'M', 1, 1),
(12571, 'ankit', 'vuiashha sjkh jhsad ', '2345678234', 'ankit12@gmail.com', '2024-01-05', '2024-01-05', 'M', 0, 2),
(12572, 'Ashok Sir', 'risali chowk, bhilai', '9687845688', 'ashok21@gmail.com', '2024-01-06', '2024-01-06', 'M', 1, 2),
(12596, '', '', '', '', '0000-00-00', '0000-00-00', '', 0, 0),
(12597, 'Premiumm', 'ghsagh', '6387426865', 'remuyg@gihask.com', '2024-01-24', '2024-01-24', 'F', 1, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dept`
--
ALTER TABLE `dept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `emp`
--
ALTER TABLE `emp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12598;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
