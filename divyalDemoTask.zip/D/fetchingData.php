<?php
$con = mysqli_connect('localhost','root','','divyal') or die("Error " . mysqli_error($con));

$sql = "select emp.id,  emp.emp_name, dept.dName, emp.mobile, emp.email from emp inner join dept on emp.dept_id=dept.id";      
if (!empty($_POST['employeeName'])) {
    $employeeName = mysqli_real_escape_string($con, $_POST['employeeName']);
    $sql .= " AND emp_name LIKE '%$employeeName%'";
}

if (!empty($_POST['email'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $sql .= " AND email LIKE '%$email%'";
}

if (!empty($_POST['mobile'])) {
    $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
    $sql .= " AND mobile LIKE '%$mobile%'";
}

if (!empty($_POST['department'])) {
    $department = mysqli_real_escape_string($con, $_POST['department']);
    $sql .= " AND dept.id = $department";
}

$result = mysqli_query($con, $sql);

while($row = mysqli_fetch_assoc($result)) {
    $array[] = $row;
}

$array= $array ?? [];
$dataset = array(
    "echo" => 1,
    "totalrecords" => count($array),
    "totaldisplayrecords" => count($array),
    "data" => $array
);

echo json_encode($dataset);
?>