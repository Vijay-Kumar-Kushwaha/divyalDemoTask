    <?php        
    $d = $_POST['id'];
    $con = mysqli_connect('localhost','root','','divyal') or die('Error ' . mysqli_error($con));
    $sql = "SELECT * FROM emp WHERE id = '$d'";
    $query = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($query);
    echo json_encode($row);
    ?>